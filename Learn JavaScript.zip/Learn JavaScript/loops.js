for(let index=0; index<10;index++){
    const element=index;
    console.log(element);
   
}

// for(let i=0;i<10;i++){
//     console.log(`outer loop ${i}`);
//     for(let j=0;j<=10;j++){
//         console.log(`inner loop value${j} and inner loop${i}`);
// //         console.log(i+'*'+ j+ ' = '+ i*j);
//     }
// }

 let myArray=["nilesh","sagar","shivam"]
 console.log(myArray.length);
 for(let index=0;index<myArray.length;index++){
    const element=myArray[index];
    console.log(element);
 }
 for (let index = 1; index <= 20; index++) {
    if(index==5){
        console.log(`detected 5`);
        break;
    }
    console.log(`value of i is${index}`)
    
 }
  for (let index = 1; index <= 20; index++) {
    if(index==5){
        console.log(`detected 5`);
        continue
    }
    console.log(`value of i is${index}`)
    
 }

//  let x=0
//  while(x<=10){
//     console.log(`value of x is${x}`);
//     x++4
//  }

let arry=['flash','batman','supernam']
let i=0;
while(i<myArray.length){
    console.log(`value is ${i}`);
    i++
}

/// do while 
let score =1
do{
    console.log(`score is ${score}`);
    score++
}while(score<=10);

/// loop for arrays
///1. foe of loop
const arr=[1,2,3,3,5]
for (const num of arr) {
    console.log(num);
}

// maps
const map=new Map()
map.set('IN',"india")
map.set('USA',"unite states od america")
map.set('Fr',"France")
console.log(map);
 for(const[key,value]of map){
    console.log(key,':-',value);
 }

 //// for each loop

 const coding=['java','C','python','.NEt']
//  coding.forEach(function(val){
//     console.log(val);
//  })

coding.forEach((val)=>{
    console.log(val);
})
// fileter
const myNums=[1,2,3,4,5,5,76,654,2]
const newNums= myNums.filter((num)=> {
    return num >4
})
 console.log(newNums);

///maps
const newmun=myNums.map((num)=>{ return num+10})

//reduce
// const mynum=[1,2,3]
// const mutotal=mynum.reduce(function(acc,curreal)){
//     return acc+currval;
// }
// console.log(mutotal);

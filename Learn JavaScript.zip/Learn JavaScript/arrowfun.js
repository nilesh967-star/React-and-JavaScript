const chai=()=>{
    let ussername="milesh"
    console.log(this);
}
chai()
console.log("nilesh");

// const addTwo=(num1,num2)=>{
//      return num1+num2;
// }
// const addTwo=(num1,num2)=>num1+num2
const addTwo=(num1,num2)=>(num1+num2)
console.log(addTwo(2,5));
const addshow=()=>({ussername:"nilesh"})
console.log(addshow());

(function chai2(){
    console.log(`DB conected`);
})()

// ( (names)=>{
//     console.log(`DB conected two${name}`);
// }) ('sagar')
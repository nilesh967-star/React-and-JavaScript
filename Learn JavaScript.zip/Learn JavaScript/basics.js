const studentName="nilesh"
let studentCity="risod"
var studentEd="Engineering"
studentsports="cricket"

//studentName="tushar"
console.log(studentName);


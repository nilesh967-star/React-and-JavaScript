if(1=="1"){
    console.log("executed");
}
if(1==="1"){ /// === he type pn check krte
    console.log("executed");
}

const tempreture=41
if(tempreture==41){
    console.log("less than 50");
} else{
    console.log("is grter that 50");
}

///////  switch statement
const month=7

switch(month){
   case 1 :
    console.log("jan");
    break;
   case 2:
    console.log("feb");
    break;
   case 3:
    console.log("march");
    break;
   case 4:
    console.log("april");
    break;
   case 5:
    console.log("may");
    break;  
  default: 
   console.log(" it is month");
    break;
}